package com.codingdojo.JavaBelt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaBeltApplicationTests {

	@Test
	void contextLoads() {
	}

}
